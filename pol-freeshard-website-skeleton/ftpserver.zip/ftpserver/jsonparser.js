class JSONParser {
    
    constructor() {}
    
    static StartJSONParser() {
        console.log('Starting JSON parser...');
    }
    
}

module.exports = JSONParser;